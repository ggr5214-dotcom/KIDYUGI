from imports import Lyric, SongLyric, Color

# Esempio: sostituisci il testo con quello che vuoi.
# Lyric(testo, pausa_tra_lettere, pausa_dopo_la_frase, color=colore)
lyrics = [
    Lyric("Questo è un esempio", 0.05, 0.3, color=Color.WHITE),
    Lyric("Il testo appare lettera per lettera", 0.06, 0.4, color=Color.CYAN),
    Lyric("(e puoi cambiare i colori)", 0.08, 0.4, color=Color.MAGENTA),
]

canzone = SongLyric(lyrics)
canzone.play()
