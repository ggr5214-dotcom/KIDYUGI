import time
import os


class Color:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    BOLD = "\033[1m"


class Lyric():
    def __init__(this, text: str, char_pause: float, phrase_pause: float, new_line: bool = True, color: str = ""):
        this.text = text
        this.char_pause = char_pause
        this.phrase_pause = phrase_pause
        this.new_line = new_line
        this.color = color


class SongLyric():
    def __init__(this, lyrics: list[Lyric]):
        this.lyrics = lyrics

    def play(this):
        # Questa riga "sveglia" i colori ANSI anche sul vecchio Prompt dei comandi di Windows
        os.system("")
        # cls su Windows, clear su Linux/Mac
        os.system("cls" if os.name == "nt" else "clear")

        for lyric in this.lyrics:
            if lyric.color:
                print(lyric.color, end="", flush=True)

            for char in lyric.text:
                print(char, flush=True, end="")
                time.sleep(lyric.char_pause)

            if lyric.color:
                print(Color.RESET, end="", flush=True)

            time.sleep(lyric.phrase_pause)
            if lyric.new_line:
                print()
