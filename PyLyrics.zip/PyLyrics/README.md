# PyLyrics

Fa apparire il testo di una canzone nel terminale, lettera per lettera e a colori.
Pensato per registrare video (TikTok, Reels, Shorts).

## Come si usa

1. Installa [Python](https://www.python.org/) (spunta "Add Python to PATH").
2. Apri la cartella `Canzoni` nel terminale.
3. Lancia l'esempio:

```
python esempio.py
```

## Fare la tua canzone

1. Copia `esempio.py` e rinominalo (es. `miacanzone.py`).
2. Modifica la lista `lyrics`: ogni `Lyric(...)` ha
   - il testo,
   - la pausa tra le lettere (più alto = più lento),
   - la pausa dopo la frase,
   - il colore (`Color.WHITE`, `Color.CYAN`, `Color.MAGENTA`, ...).
3. Lancia il tuo file con `python miacanzone.py`.

La musica si aggiunge dopo, nel programma con cui monti il video.
